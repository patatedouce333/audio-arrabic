# KiloClaw Clone — Guide d'installation

**Architecture source :** KiloClaw sur Fly.io (Debian bookworm, x86_64)  
**Stack :** Node.js 22 + Python 3.11 + Go 1.26 + OpenClaw 2026.3.13

---

## 1. Système (Debian bookworm recommandé)

```bash
sudo apt-get update
sudo apt-get install -y curl wget git python3 python3-pip
```

## 2. Node.js 22 (version exacte)

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -
sudo apt-get install -y nodejs
# Vérifier : v22.22.1
node --version
```

## 3. Packages npm globaux

```bash
npm install -g mcporter@0.8.1
npm install -g @browserbasehq/mcp@3.0.0
```

## 4. OpenClaw

```bash
npm install -g openclaw
openclaw --version  # → OpenClaw 2026.3.13
```

## 5. Kilo CLI

```bash
curl -fsSL https://kilo.ai/install.sh | bash
# Vérifier
kilo --version
```

## 6. Go (optionnel)

```bash
# Via goup ou apt
# go version → go1.26.0
```

## 7. Configuration

### openclaw.json → `~/.openclaw/openclaw.json`

```bash
mkdir -p ~/.openclaw
cp openclaw.json ~/.openclaw/openclaw.json
```

**À éditer avant de lancer :**
- `channels.telegram.botToken` → ton token BotFather
- `gateway.auth.token` → génère une clé (uuid ou hash)
- `channels.streamchat` → ta config StreamChat (si utilisé)
- `tools.web.search.apiKey` → ta clé Brave API

### Brave API → `~/.openclaw/.env`

```bash
echo "BRAVE_API_KEY=ta_cle_ici" > ~/.openclaw/.env
```

### mcporter → `~/.openclaw/workspace/config/mcporter.json`

```bash
mkdir -p ~/.openclaw/workspace/config
cp mcporter.json ~/.openclaw/workspace/config/mcporter.json
```

**À éditer :** Remplace tous les `YOUR_KEY_HERE` par tes clés réelles (Brave, Tavily, Apify, Browserbase).

### Workspace

```bash
mkdir -p ~/.openclaw/workspace/memory
cp -r workspace/* ~/.openclaw/workspace/
```

## 8. Lancer

```bash
openclaw gateway
```

## 9. Telegram

1. Créer le bot via @BotFather → copier le token
2. Le mettre dans `openclaw.json`
3. Lancer le gateway
4. Pairer : `/start` dans le DM Telegram

## 10. Groupes

La config a déjà `groupPolicy: "open"` + `requireMention: false` pour tous les groupes.

---

## Résumé des dépendances

| Composant | Version | Source |
|---|---|---|
| OS | Debian 12 (bookworm) | — |
| Kernel | 6.12.47-fly | Fly.io custom |
| Node.js | 22.22.1 | nodesource |
| npm | 10.9.4 | avec Node.js |
| Python | 3.11.2 | apt |
| Go | 1.26.0 | golang.org |
| OpenClaw | 2026.3.13 | npm |
| mcporter | 0.7.3 / 0.8.1 | npm |
| @browserbasehq/mcp | 3.0.0 | npm |
| tavily-mcp | 0.2.3 | npx (via mcporter) |
| @modelcontextprotocol/server-brave-search | latest | npx (via mcporter) |
| @apify/actors-mcp-server | latest | npx (via mcporter) |
| gh CLI | 2.89.0 | apt/github |
| kilo CLI | latest | kilo.ai/install.sh |

## Espace requis

- **Minimum** : ~2 Go (sans cache npm)
- **Confortable** : 10 Go+ (avec cache npm ~400 Mo, logs, projets)
- **RAM** : 3 Go minimum (openclaw-gateway prend ~500 Mo)
- **CPU** : 2 vCPU minimum
